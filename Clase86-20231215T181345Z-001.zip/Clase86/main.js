// Crea la variable de referncia del lienzo usando fabric.Canvas()
var canvas = new fabric.Canvas('myCanvas');

//Define el ancho inicial y el alto del cloque de imágenes 


//Define el inicio de las coordenadas  y Y del jugador 


// Define una variable llamada player_object para almacenar la imagen del jugador


// Agrega una función llamada player_update() para agregar la imagen del jugador 
function player_update(){
  
}

// Agrega una función llamada new_image() para agregar las diferentes imágene al presionar teclas específicas.
function new_image(){
    
}